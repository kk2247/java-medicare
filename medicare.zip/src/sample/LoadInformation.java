package sample;

import java.io.IOException;

public interface LoadInformation {
    public void load() throws IOException, ClassNotFoundException;
}
